import mongoose from "mongoose";

// MongoDB Connection
let cachedDb = null;

async function connectToDatabase() {
  if (cachedDb) {
    return cachedDb;
  }

  const mongoURI = process.env.MONGO_URI;
  
  await mongoose.connect(mongoURI, {
    dbName: "test",
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });

  cachedDb = mongoose.connection;
  return cachedDb;
}

// Define Schemas
const sessionSchema = new mongoose.Schema(
  { sessionId: String, createdAt: Date },
  { collection: "sessions" }
);

const parameterSchema = new mongoose.Schema(
  {
    sessionId: String,
    bloodPressure: {
      systolic: Number,
      diastolic: Number,
      createdAt: Date,
    },
    heartRate: Number,
    oxygenLevel: Number,
    temperature: Number,
    updatedAt: Date,
  },
  { collection: "parameters" }
);

const Session = mongoose.models.Session || mongoose.model("Session", sessionSchema);
const Parameter = mongoose.models.Parameter || mongoose.model("Parameter", parameterSchema);

// Save BP Result Function
async function saveBPResult({ systolic, diastolic, oxygenLevel, heartRate }) {
  try {
    const latestSession = await Session.findOne().sort({ createdAt: -1 });
    if (!latestSession) {
      console.log("⚠️ No session found in test.sessions");
      return;
    }

    const sid = latestSession.sessionId;
    const existingParam = await Parameter.findOne({ sessionId: sid });

    if (!existingParam) {
      const newParam = new Parameter({
        sessionId: sid,
        bloodPressure: {
          systolic,
          diastolic,
          createdAt: new Date(),
        },
        heartRate,
        oxygenLevel,
        updatedAt: new Date(),
      });
      await newParam.save();
      console.log(`🆕 Created new parameter for session ${sid}`);
    } else {
      await Parameter.updateOne(
        { sessionId: sid },
        {
          $set: {
            "bloodPressure.systolic": systolic,
            "bloodPressure.diastolic": diastolic,
            "bloodPressure.createdAt": new Date(),
            heartRate,
            oxygenLevel,
            updatedAt: new Date(),
          },
        }
      );
      console.log(`✅ Updated BP & SpO₂ for session ${sid}`);
    }
  } catch (err) {
    console.error("❌ Error saving BP result:", err);
    throw err;
  }
}

// Lambda Handler
export const handler = async (event) => {
  console.log("Event:", JSON.stringify(event, null, 2));

  // CORS headers
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json",
  };

  // Handle OPTIONS preflight request
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ message: "OK" }),
    };
  }

  try {
    // Connect to database
    await connectToDatabase();

    // Parse body
    const body = JSON.parse(event.body || "{}");
    const latestBP = body.value || "";

    console.log("🩺 Received BP:", latestBP);

    // Process only if we received final reading
    if (latestBP.includes("Result")) {
      const bpMatch = latestBP.match(/(\d+)\s*\/\s*(\d+)/);
      const bpmMatch = latestBP.match(/BPM\s*:\s*(\d+)/);

      if (bpMatch) {
        const systolic = parseInt(bpMatch[1]);
        const diastolic = parseInt(bpMatch[2]);
        const heartRate = bpmMatch ? parseInt(bpmMatch[1]) : null;

        // Save to database
        await saveBPResult({
          systolic,
          diastolic,
          heartRate,
          oxygenLevel: null, // Will be updated by SpO2 endpoint
        });
      }
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ success: true, message: "BP data received" }),
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
    };
  }
};
