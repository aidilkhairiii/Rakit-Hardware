import mongoose from "mongoose";

// MongoDB Connection
let cachedDb = null;

async function connectToDatabase() {
  if (cachedDb) {
    return cachedDb;
  }

  const mongoURI = process.env.MONGO_URI;
  
  await mongoose.connect(mongoURI, {
    dbName: "test",
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });

  cachedDb = mongoose.connection;
  return cachedDb;
}

// Define Schema
const parameterSchema = new mongoose.Schema(
  {
    sessionId: String,
    bloodPressure: {
      systolic: Number,
      diastolic: Number,
      createdAt: Date,
    },
    heartRate: Number,
    oxygenLevel: Number,
    temperature: Number,
    updatedAt: Date,
  },
  { collection: "parameters" }
);

const sessionSchema = new mongoose.Schema(
  { sessionId: String, createdAt: Date },
  { collection: "sessions" }
);

const Parameter = mongoose.models.Parameter || mongoose.model("Parameter", parameterSchema);
const Session = mongoose.models.Session || mongoose.model("Session", sessionSchema);

// Lambda Handler
export const handler = async (event) => {
  console.log("Event:", JSON.stringify(event, null, 2));

  // CORS headers
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json",
  };

  // Handle OPTIONS preflight request
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ message: "OK" }),
    };
  }

  try {
    // Connect to database
    await connectToDatabase();

    // Parse body
    const body = JSON.parse(event.body || "{}");
    const latestTemp = body.value || "";

    console.log("🌡️ Received Temperature:", latestTemp);

    // Parse temperature
    const tempMatch = latestTemp.match(/([0-9]+\.?[0-9]*)\s*°?\s*[Cc]?/);
    const temperature = tempMatch ? parseFloat(tempMatch[1]) : null;

    // Update latest session
    if (temperature !== null) {
      const latestSession = await Session.findOne().sort({ createdAt: -1 });
      
      if (latestSession) {
        await Parameter.updateOne(
          { sessionId: latestSession.sessionId },
          {
            $set: {
              temperature,
              updatedAt: new Date(),
            },
          }
        );

        console.log(`🌡️ Temperature updated for session ${latestSession.sessionId}: ${temperature}°C`);
      }
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ 
        success: true, 
        message: "Temperature data received",
        temperature 
      }),
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
    };
  }
};
