import mongoose from "mongoose";

// MongoDB Connection
let cachedDb = null;

async function connectToDatabase() {
  if (cachedDb) {
    return cachedDb;
  }

  const mongoURI = process.env.MONGO_URI;
  
  await mongoose.connect(mongoURI, {
    dbName: "test",
    useNewUrlParser: true,
    useUnifiedTopology: true,
  });

  cachedDb = mongoose.connection;
  return cachedDb;
}

// Define Schema
const parameterSchema = new mongoose.Schema(
  {
    sessionId: String,
    bloodPressure: {
      systolic: Number,
      diastolic: Number,
      createdAt: Date,
    },
    heartRate: Number,
    oxygenLevel: Number,
    temperature: Number,
    updatedAt: Date,
  },
  { collection: "parameters" }
);

const sessionSchema = new mongoose.Schema(
  { sessionId: String, createdAt: Date },
  { collection: "sessions" }
);

const Parameter = mongoose.models.Parameter || mongoose.model("Parameter", parameterSchema);
const Session = mongoose.models.Session || mongoose.model("Session", sessionSchema);

// Lambda Handler
export const handler = async (event) => {
  console.log("Event:", JSON.stringify(event, null, 2));

  // CORS headers
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json",
  };

  // Handle OPTIONS preflight request
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ message: "OK" }),
    };
  }

  try {
    // Connect to database
    await connectToDatabase();

    // Parse body
    const body = JSON.parse(event.body || "{}");
    const latestSpo2 = body.value || "";

    console.log("🫁 Received SpO₂:", latestSpo2);

    // Parse SpO2 and BPM
    const spo2Match = latestSpo2.match(/SpO2\s*:\s*(\d+)%/);
    const bpmMatch = latestSpo2.match(/BPM\s*:\s*(\d+)/);

    const oxygenLevel = spo2Match ? parseInt(spo2Match[1]) : null;
    const heartRate = bpmMatch ? parseInt(bpmMatch[1]) : null;

    // Update latest session
    if (oxygenLevel !== null || heartRate !== null) {
      const latestSession = await Session.findOne().sort({ createdAt: -1 });
      
      if (latestSession) {
        const updateData = {
          updatedAt: new Date(),
        };
        
        if (oxygenLevel !== null) {
          updateData.oxygenLevel = oxygenLevel;
        }
        if (heartRate !== null) {
          updateData.heartRate = heartRate;
        }

        await Parameter.updateOne(
          { sessionId: latestSession.sessionId },
          { $set: updateData }
        );

        console.log(`✅ Updated SpO₂ for session ${latestSession.sessionId}`);
      }
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ success: true, message: "SpO2 data received" }),
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
    };
  }
};
